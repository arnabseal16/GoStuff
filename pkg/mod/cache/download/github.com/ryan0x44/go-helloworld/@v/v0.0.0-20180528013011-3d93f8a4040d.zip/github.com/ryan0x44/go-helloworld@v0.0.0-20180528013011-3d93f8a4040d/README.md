# Go "Hello World!" example

To download:

```
go get github.com/ryan0x44/go-helloworld
```

To run the binary:

```
$GOPATH/bin/go-helloworld
```

To run `main.go` directly:

```
cd $GOPATH/src/github.com/ryan0x44/go-helloworld
go run main.go
```

